// SetTimeOut
// setTimeout(() => {
//     // console.log(99999999999999); 
//     console.log("Today Day => " + date.getDate());
//     console.log("Today Month => " + date.getMonth());
//     console.log("Today Year => " + date.getFullYear());
    
//     console.log(date.getSeconds());
//     console.log(date.getMinutes());
//     console.log(date.getHours());
//     clearInterval()
// }, 5000);
 
 
// Date Time
const date = new Date();
// console.log(date);


// SetInterval
// setInterval(() => {
//    console.log("Call every second");
   
// }, 1000);

// Slice
// Array123 = ["A", "B", "C", "D", "E"]
// Array123 = Array123.slice(1, 3)
// console.log(Array123);

// Splice
// Array123 = ["A", "B", "C", "D", "E"]
// Array1 = Array123.splice(1, 0)
// console.log(Array1);

// Array2 = Array123.splice(1, 3)
// console.log(Array2);

// const fruits = ["Banana", "Orange", "Apple", "Mango"];
// fruits.splice(0, 1, "Lemon", "Kiwi");
// console.log(fruits)

// values add kerna start kerre ga index #2
// 1 value remove kerra hay
// index # 2 k baad "Lemon", "Kiwi" add kia hay



Array123 = ["A", "B", "C", "D", "E"]
// a = Array123.slice(1, 3)
// console.log(a);

