Array1 = ["Ali", "Ahemd", "Adan", "Amir", "Asif"]

console.log("Before push");
console.log(Array1);

Array1.push("Bilal")
Array1.push("Hamza")

console.log("After push");
console.log(Array1);

Array1.pop()
Array1.pop()

console.log("After pop");
console.log(Array1);

// for (i = 0; i < Array1.length; i++) {
//     // console.log("2 x "  + i  +  " = " + i*2);
//     console.log(Array1[i]);
// }

// for (i = 10; i>=1; i--) {
//     // console.log("2 x "  + i  +  " = " + i*2);
//     console.log(Array1[i]);
// }



// i=  1 true
// i=  2 true
// .
// .
// .
// i=  9 true
// i=  10 true
// i=  11 false