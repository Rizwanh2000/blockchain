rollNo1 = 520
rollNo2 = 520
rollNo30 = 520
// name  = "Ali"
// // 123= "isahknm,"
// yesNo = true
// // /false

// console.log(rollNo1);
// console.log(rollNo2);
// console.log(rollNo30);
// console.log(name);
//        0           1       2       3       4       5
ahmed =  [rollNo1, rollNo2, rollNo30, "asdf", true, 845120, 132,2123,233]

// console.log(ahmed);
// console.log(ahmed[5]);

// // forward 
// for (i = 0; i < Array1.length; i++) {
//     // console.log("2 x "  + i  +  " = " + i*2);
//     console.log(Array1[i]);
// }

// // backward
// for (i = 10; i>=1; i--) {
//     // console.log("2 x "  + i  +  " = " + i*2);
//     console.log(Array1[i]);
// }

// ahmed.forEach( (value, i) => {
//     console.log(i);
// });


// for (const item of ahmed) {
//     console.log(item);
// }

student = {
    name: "Mustafa",
    course: "Blcokchain",
    section: "A",
    batch: 2,
    status: true,
    result: [ 90, 50, 78, 'class', false, ' 4561', 84152 ]
}

// console.log(student.course);
// console.log(student["course"]);

// yay sirf object pay looping kerne k liay hay
// for (const key in student) {
//     if (student.hasOwnProperty.call(student, key)) {
//         const element = student[key];
//         console.log(element);
//     }
// }

a = 0
// while (a < 5) {
//     console.log(a);
//     a++;
// }

do {
    console.log(a);
    a++;    
} while (a > 5);