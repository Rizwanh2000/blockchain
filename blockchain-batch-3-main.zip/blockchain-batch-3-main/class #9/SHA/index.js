const SHA123 = require("sha256");
console.log(SHA123("1"));

