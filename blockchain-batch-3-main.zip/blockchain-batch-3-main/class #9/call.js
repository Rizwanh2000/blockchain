// const {student123} = require("./student")
const asdw43445 = require("./student")
// a123 = student123

Student = new asdw43445("Ali", 123)
// Student22222222 = new student123("Ali", 123)
Student.getName()
// Student22222222.getName()