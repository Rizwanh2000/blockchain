Mustafa = "845120sasccv"
name = Mustafa
phone = 123
yesNo  = true

marks = [90,50,78, "class", false, " 4561", 84152]

// console.log(marks[0]);
// console.log(marks[2] + marks[2]);

//   0   1   2      3      4        5       6
// [ 90, 50, 78, 'class', false, ' 4561', 84152 ]

student = {
   name: "Mustafa",
   course: "Blcokchain",
   section: "A",
   batch: 2,
   status: true,
   result: [ 90, 50, 78, 'class', false, ' 4561', 84152 ]
}

console.log(student);
console.log(student.course);
console.log(student.result[5]);
// student = {
//    key: value 
// }